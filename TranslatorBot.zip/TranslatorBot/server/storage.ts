import { 
  type User, type InsertUser,
  type Note, type InsertNote,
  type CanvaLink, type InsertCanvaLink,
  type MoodBoardImage, type InsertMoodBoardImage,
  type Resource, type InsertResource
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getNotesByUserId(userId: string): Promise<Note[]>;
  createNote(userId: string, note: InsertNote): Promise<Note>;
  updateNote(id: string, note: Partial<InsertNote>): Promise<Note | undefined>;
  deleteNote(id: string): Promise<boolean>;
  
  getCanvaLinksByUserId(userId: string): Promise<CanvaLink[]>;
  createCanvaLink(userId: string, link: InsertCanvaLink): Promise<CanvaLink>;
  deleteCanvaLink(id: string): Promise<boolean>;
  
  getMoodBoardImagesByUserId(userId: string): Promise<MoodBoardImage[]>;
  createMoodBoardImage(userId: string, image: InsertMoodBoardImage): Promise<MoodBoardImage>;
  deleteMoodBoardImage(id: string): Promise<boolean>;
  
  getResourcesByUserId(userId: string): Promise<Resource[]>;
  createResource(userId: string, resource: InsertResource): Promise<Resource>;
  deleteResource(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private notes: Map<string, Note>;
  private canvaLinks: Map<string, CanvaLink>;
  private moodBoardImages: Map<string, MoodBoardImage>;
  private resources: Map<string, Resource>;

  constructor() {
    this.users = new Map();
    this.notes = new Map();
    this.canvaLinks = new Map();
    this.moodBoardImages = new Map();
    this.resources = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async getNotesByUserId(userId: string): Promise<Note[]> {
    return Array.from(this.notes.values()).filter(note => note.userId === userId);
  }

  async createNote(userId: string, insertNote: InsertNote): Promise<Note> {
    const id = randomUUID();
    const note: Note = {
      id,
      userId,
      title: insertNote.title,
      content: insertNote.content,
      category: insertNote.category || 'general',
      tags: insertNote.tags || [],
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.notes.set(id, note);
    return note;
  }

  async updateNote(id: string, updateData: Partial<InsertNote>): Promise<Note | undefined> {
    const note = this.notes.get(id);
    if (!note) return undefined;
    
    const updatedNote: Note = {
      ...note,
      ...updateData,
      category: updateData.category || note.category,
      tags: updateData.tags || note.tags,
      updatedAt: new Date()
    };
    this.notes.set(id, updatedNote);
    return updatedNote;
  }

  async deleteNote(id: string): Promise<boolean> {
    return this.notes.delete(id);
  }

  async getCanvaLinksByUserId(userId: string): Promise<CanvaLink[]> {
    return Array.from(this.canvaLinks.values()).filter(link => link.userId === userId);
  }

  async createCanvaLink(userId: string, insertLink: InsertCanvaLink): Promise<CanvaLink> {
    const id = randomUUID();
    const link: CanvaLink = {
      id,
      userId,
      title: insertLink.title,
      url: insertLink.url,
      thumbnail: insertLink.thumbnail || null,
      tags: insertLink.tags || [],
      notes: insertLink.notes || null,
      createdAt: new Date()
    };
    this.canvaLinks.set(id, link);
    return link;
  }

  async deleteCanvaLink(id: string): Promise<boolean> {
    return this.canvaLinks.delete(id);
  }

  async getMoodBoardImagesByUserId(userId: string): Promise<MoodBoardImage[]> {
    return Array.from(this.moodBoardImages.values()).filter(image => image.userId === userId);
  }

  async createMoodBoardImage(userId: string, insertImage: InsertMoodBoardImage): Promise<MoodBoardImage> {
    const id = randomUUID();
    const image: MoodBoardImage = {
      id,
      userId,
      projectId: insertImage.projectId || null,
      imageUrl: insertImage.imageUrl,
      title: insertImage.title || null,
      tags: insertImage.tags || [],
      position: insertImage.position || {},
      createdAt: new Date()
    };
    this.moodBoardImages.set(id, image);
    return image;
  }

  async deleteMoodBoardImage(id: string): Promise<boolean> {
    return this.moodBoardImages.delete(id);
  }

  async getResourcesByUserId(userId: string): Promise<Resource[]> {
    return Array.from(this.resources.values()).filter(resource => resource.userId === userId);
  }

  async createResource(userId: string, insertResource: InsertResource): Promise<Resource> {
    const id = randomUUID();
    const resource: Resource = {
      id,
      userId,
      name: insertResource.name,
      type: insertResource.type,
      url: insertResource.url || null,
      filePath: insertResource.filePath || null,
      tags: insertResource.tags || [],
      metadata: insertResource.metadata || {},
      createdAt: new Date()
    };
    this.resources.set(id, resource);
    return resource;
  }

  async deleteResource(id: string): Promise<boolean> {
    return this.resources.delete(id);
  }
}

export const storage = new MemStorage();
