import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  status: text("status").notNull().default("active"),
  data: jsonb("data").notNull().default('{}'),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const canvaLinks = pgTable("canva_links", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  title: text("title").notNull(),
  url: text("url").notNull(),
  thumbnail: text("thumbnail"),
  tags: jsonb("tags").default('[]'),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const moodBoardImages = pgTable("mood_board_images", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  projectId: varchar("project_id"),
  imageUrl: text("image_url").notNull(),
  title: text("title"),
  tags: jsonb("tags").default('[]'),
  position: jsonb("position").default('{}'),
  createdAt: timestamp("created_at").defaultNow(),
});

export const notes = pgTable("notes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  category: text("category").notNull().default("general"),
  tags: jsonb("tags").default('[]'),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const resources = pgTable("resources", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  url: text("url"),
  filePath: text("file_path"),
  tags: jsonb("tags").default('[]'),
  metadata: jsonb("metadata").default('{}'),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  name: true,
});

export const insertProjectSchema = createInsertSchema(projects).pick({
  name: true,
  description: true,
  category: true,
  status: true,
  data: true,
});

export const insertCanvaLinkSchema = createInsertSchema(canvaLinks).pick({
  title: true,
  url: true,
  thumbnail: true,
  tags: true,
  notes: true,
});

export const insertMoodBoardImageSchema = createInsertSchema(moodBoardImages).pick({
  projectId: true,
  imageUrl: true,
  title: true,
  tags: true,
  position: true,
});

export const insertNoteSchema = createInsertSchema(notes).pick({
  title: true,
  content: true,
  category: true,
  tags: true,
});

export const insertResourceSchema = createInsertSchema(resources).pick({
  name: true,
  type: true,
  url: true,
  filePath: true,
  tags: true,
  metadata: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;

export type CanvaLink = typeof canvaLinks.$inferSelect;
export type InsertCanvaLink = z.infer<typeof insertCanvaLinkSchema>;

export type MoodBoardImage = typeof moodBoardImages.$inferSelect;
export type InsertMoodBoardImage = z.infer<typeof insertMoodBoardImageSchema>;

export type Note = typeof notes.$inferSelect;
export type InsertNote = z.infer<typeof insertNoteSchema>;

export type Resource = typeof resources.$inferSelect;
export type InsertResource = z.infer<typeof insertResourceSchema>;
