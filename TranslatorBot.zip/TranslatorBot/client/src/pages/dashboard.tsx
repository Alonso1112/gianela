import { useState, useEffect } from 'react';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { useTheme } from '@/hooks/use-theme';
import { Button } from '@/components/ui/button';
import Sidebar from '@/components/sidebar';
import FloatingMessage from '@/components/floating-message';
import CanvaBoard from '@/components/tabs/canva-board';
import MoodBoard from '@/components/tabs/mood-board';
import Projects from '@/components/tabs/projects';
import AITools from '@/components/tabs/ai-tools';
import Inspiration from '@/components/tabs/inspiration';
import Typography from '@/components/tabs/typography';
import Notes from '@/components/tabs/notes';
import { Menu, Sun, Moon, CircleEqual, Download, FileCode } from 'lucide-react';

type Tab = 'canva' | 'moodboard' | 'projects' | 'ai-tools' | 'inspiration' | 'typography' | 'notes';

const TABS = [
  { id: 'canva' as Tab, label: 'Mini Canva Board', icon: '🎨' },
  { id: 'moodboard' as Tab, label: 'Mood Board', icon: '🖼️' },
  { id: 'projects' as Tab, label: 'Mis Proyectos', icon: '📁' },
  { id: 'ai-tools' as Tab, label: 'Herramientas IA', icon: '🤖' },
  { id: 'inspiration' as Tab, label: 'Inspiración', icon: '💡' },
  { id: 'typography' as Tab, label: 'Tipografías', icon: '🔤' },
  { id: 'notes' as Tab, label: 'Notas', icon: '📝' }
];

export default function Dashboard() {
  const { theme, setTheme } = useTheme();
  const [activeTab, setActiveTab] = useLocalStorage<Tab>('activeTab', 'canva');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [currentDate, setCurrentDate] = useState('');
  const [showAutoSave, setShowAutoSave] = useState(false);

  useEffect(() => {
    const now = new Date();
    const dateString = now.toLocaleDateString('es-ES', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
    setCurrentDate(dateString);
  }, []);

  useEffect(() => {
    // Show auto-save indicator periodically
    const interval = setInterval(() => {
      setShowAutoSave(true);
      setTimeout(() => setShowAutoSave(false), 3000);
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const exportData = (format: 'json' | 'txt') => {
    const data = {
      canvaLinks: JSON.parse(localStorage.getItem('canvaLinks') || '[]'),
      moodBoardImages: JSON.parse(localStorage.getItem('moodBoardImages') || '[]'),
      projects: {
        brief: JSON.parse(localStorage.getItem('projectBrief') || '{}'),
        valueProposition: JSON.parse(localStorage.getItem('valueProposition') || '{}'),
        swotAnalysis: JSON.parse(localStorage.getItem('swotAnalysis') || '{}'),
        resources: JSON.parse(localStorage.getItem('projectResources') || '[]')
      },
      notes: JSON.parse(localStorage.getItem('notes') || '[]'),
      settings: {
        theme,
        activeTab
      },
      exportedAt: new Date().toISOString()
    };

    const filename = `gianela-creative-backup-${new Date().toISOString().split('T')[0]}`;
    
    if (format === 'json') {
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } else {
      const textContent = Object.entries(data)
        .map(([key, value]) => `${key.toUpperCase()}:\n${typeof value === 'string' ? value : JSON.stringify(value, null, 2)}\n\n`)
        .join('');
      
      const blob = new Blob([textContent], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}.txt`;
      a.click();
      URL.revokeObjectURL(url);
    }

    // Show success toast
    const toast = document.createElement('div');
    toast.className = 'save-indicator';
    toast.textContent = `Respaldo exportado en formato ${format.toUpperCase()} 📁`;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'canva':
        return <CanvaBoard />;
      case 'moodboard':
        return <MoodBoard />;
      case 'projects':
        return <Projects />;
      case 'ai-tools':
        return <AITools />;
      case 'inspiration':
        return <Inspiration />;
      case 'typography':
        return <Typography />;
      case 'notes':
        return <Notes />;
      default:
        return <CanvaBoard />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="glass sticky top-0 z-50 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Left: Menu & Logo */}
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                data-testid="button-toggle-sidebar"
              >
                <Menu className="h-5 w-5" />
              </Button>
              <h1 className="text-2xl font-serif font-bold hidden sm:block">
                Espacio Creativo
              </h1>
            </div>
            
            {/* Center: Greeting */}
            <div className="hidden md:block text-center">
              <p className="text-sm text-muted-foreground">¡Hola!</p>
              <p className="font-accent font-semibold text-lg">
                Gianela 🌞
              </p>
              <p className="text-xs text-muted-foreground">{currentDate}</p>
            </div>
            
            {/* Right: Theme Toggle & Save Indicator */}
            <div className="flex items-center gap-3">
              {showAutoSave && (
                <div className="hidden md:flex items-center gap-2 text-sm text-green-600 dark:text-green-400">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span>Guardado ✓</span>
                </div>
              )}
              
              <div className="flex items-center gap-1 bg-muted rounded-lg p-1">
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => setTheme('light')}
                  className={`p-2 rounded-md transition-smooth ${theme === 'light' ? 'bg-background shadow-sm' : ''}`}
                  data-testid="button-theme-light"
                >
                  <Sun className="h-4 w-4 text-yellow-500" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => setTheme('dark')}
                  className={`p-2 rounded-md transition-smooth ${theme === 'dark' ? 'bg-background shadow-sm' : ''}`}
                  data-testid="button-theme-dark"
                >
                  <Moon className="h-4 w-4 text-indigo-500" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => setTheme('auto')}
                  className={`p-2 rounded-md transition-smooth ${theme === 'auto' ? 'bg-background shadow-sm' : ''}`}
                  data-testid="button-theme-auto"
                >
                  <CircleEqual className="h-4 w-4 text-gray-500" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

        {/* Main Content */}
        <main className="flex-1 transition-all duration-300">
          <div className="max-w-7xl mx-auto p-6">
            {/* Tabs Navigation */}
            <div className="glass rounded-xl p-2 mb-6 overflow-x-auto">
              <div className="flex gap-2 min-w-max">
                {TABS.map((tab) => (
                  <Button
                    key={tab.id}
                    variant={activeTab === tab.id ? 'default' : 'ghost'}
                    onClick={() => setActiveTab(tab.id)}
                    className="px-6 py-3 font-medium transition-smooth whitespace-nowrap"
                    data-testid={`button-tab-${tab.id}`}
                  >
                    <span className="mr-2">{tab.icon}</span>
                    {tab.label}
                  </Button>
                ))}
              </div>
            </div>

            {/* Tab Content */}
            <div className="fade-in">
              {renderTabContent()}
            </div>

            {/* Export Backup Section */}
            <div className="glass rounded-xl p-6 mt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-serif font-bold mb-2">Respaldo de Datos</h3>
                  <p className="text-sm text-muted-foreground">Exporta toda tu información en un archivo de respaldo</p>
                </div>
                <div className="flex gap-2">
                  <Button 
                    onClick={() => exportData('json')}
                    className="bg-secondary text-secondary-foreground hover:bg-secondary/80"
                    data-testid="button-export-json"
                  >
                    <FileCode className="w-4 h-4 mr-2" />
                    Exportar JSON
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => exportData('txt')}
                    data-testid="button-export-txt"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Exportar TXT
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Footer */}
      <footer className="glass border-t border-border mt-12 py-6">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p className="text-lg font-accent flex items-center justify-center gap-2">
            Hecho con amor por 
            <span className="text-primary font-bold">Valentino 🌙</span>
            para 
            <span className="text-accent font-bold">Gianela 🌞</span>
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            Un espacio creativo lleno de amor y magia ✨💖
          </p>
        </div>
      </footer>

      {/* Floating Romantic Message */}
      <FloatingMessage />
    </div>
  );
}
