import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';

export default function Login() {
  const [, navigate] = useLocation();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate authentication
    setTimeout(() => {
      localStorage.setItem('isAuthenticated', 'true');
      localStorage.setItem('user', JSON.stringify({ name: 'Gianela', username: 'gianela' }));
      navigate('/dashboard');
    }, 1000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary via-secondary to-accent opacity-20"></div>
      
      {/* Floating Hearts */}
      <div className="absolute top-10 left-10 text-6xl heartbeat opacity-50">💕</div>
      <div className="absolute top-20 right-20 text-5xl heartbeat opacity-40" style={{ animationDelay: '0.5s' }}>💗</div>
      <div className="absolute bottom-20 left-20 text-5xl heartbeat opacity-30" style={{ animationDelay: '1s' }}>💖</div>
      <div className="absolute bottom-10 right-10 text-6xl heartbeat opacity-50" style={{ animationDelay: '1.5s' }}>💝</div>
      
      {/* Login Card */}
      <Card className="glass rounded-3xl max-w-md w-full relative z-10 fade-in shadow-2xl">
        <CardContent className="p-10">
          {/* Pixel Art Cats */}
          <div className="flex justify-center gap-8 mb-8">
            <div className="pixel-cat relative float-animation">
              <svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
                {/* Cat face */}
                <rect x="16" y="24" width="32" height="24" fill="#FFB6C1"/>
                {/* Ears */}
                <rect x="16" y="16" width="8" height="8" fill="#FFB6C1"/>
                <rect x="40" y="16" width="8" height="8" fill="#FFB6C1"/>
                {/* Eyes */}
                <rect x="24" y="32" width="4" height="4" fill="#333"/>
                <rect x="36" y="32" width="4" height="4" fill="#333"/>
                {/* Nose */}
                <rect x="30" y="40" width="4" height="4" fill="#FF69B4"/>
                {/* Whiskers */}
                <rect x="12" y="36" width="4" height="1" fill="#333"/>
                <rect x="48" y="36" width="4" height="1" fill="#333"/>
              </svg>
            </div>
            <div className="pixel-cat relative float-animation" style={{ animationDelay: '0.5s' }}>
              <svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
                {/* Cat face */}
                <rect x="16" y="24" width="32" height="24" fill="#E6E6FA"/>
                {/* Ears */}
                <rect x="16" y="16" width="8" height="8" fill="#E6E6FA"/>
                <rect x="40" y="16" width="8" height="8" fill="#E6E6FA"/>
                {/* Eyes closed */}
                <rect x="24" y="32" width="4" height="2" fill="#333"/>
                <rect x="36" y="32" width="4" height="2" fill="#333"/>
                {/* Nose */}
                <rect x="30" y="40" width="4" height="4" fill="#9370DB"/>
                {/* Whiskers */}
                <rect x="12" y="36" width="4" height="1" fill="#333"/>
                <rect x="48" y="36" width="4" height="1" fill="#333"/>
              </svg>
            </div>
          </div>
          
          <h1 className="text-4xl font-serif font-bold text-center mb-3">
            Bienvenida a tu Espacio
          </h1>
          <p className="text-center text-muted-foreground mb-8 font-accent">
            Un lugar hecho con amor para tu creatividad ✨
          </p>
          
          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="username">Usuario</Label>
              <Input 
                id="username"
                type="text" 
                placeholder="Gianela"
                required
                data-testid="input-username"
                className="transition-smooth"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Contraseña</Label>
              <Input 
                id="password"
                type="password" 
                placeholder="••••••••"
                required
                data-testid="input-password"
                className="transition-smooth"
              />
            </div>
            
            <Button 
              type="submit"
              className="w-full py-4 font-semibold hover-lift shadow-lg font-accent"
              disabled={isLoading}
              data-testid="button-login"
            >
              {isLoading ? 'Entrando...' : '💖 Entrar a mi espacio'}
            </Button>
          </form>
          
          <div className="mt-6 flex items-center justify-center gap-2 text-sm text-muted-foreground">
            <span className="pixel-heart"></span>
            <span className="font-accent">Hecho con amor</span>
            <span className="pixel-heart"></span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
