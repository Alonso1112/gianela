import { useState } from 'react';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { X, Calendar, Target, BookOpen, Palette } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Goal {
  id: string;
  title: string;
  current: number;
  total: number;
}

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [goals, setGoals] = useLocalStorage<Goal[]>('goals', [
    { id: '1', title: 'Terminar 5 proyectos', current: 3, total: 5 },
    { id: '2', title: 'Aprender 3 herramientas IA', current: 1, total: 3 }
  ]);
  
  const [diaryEntry, setDiaryEntry] = useLocalStorage('diaryEntry', '');

  const colors = [
    { hex: '#FFB6C1', name: 'Rosa claro' },
    { hex: '#E6E6FA', name: 'Lavanda' },
    { hex: '#F08080', name: 'Coral' },
    { hex: '#DDA0DD', name: 'Ciruela' },
    { hex: '#FFE4E1', name: 'Rosa niebla' }
  ];

  const copyColor = async (color: string) => {
    try {
      await navigator.clipboard.writeText(color);
      // Show toast notification
      const toast = document.createElement('div');
      toast.className = 'save-indicator';
      toast.textContent = `Color ${color} copiado! 🎨`;
      document.body.appendChild(toast);
      setTimeout(() => toast.remove(), 2000);
    } catch (err) {
      console.error('Error copying color:', err);
    }
  };

  return (
    <aside 
      className={`sidebar fixed left-0 top-16 bottom-0 w-80 glass border-r border-border z-40 overflow-y-auto ${
        isOpen ? 'open' : ''
      }`}
    >
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h3 className="font-serif font-bold text-xl">Mi Espacio</h3>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onClose}
            data-testid="button-close-sidebar"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Mini Calendar */}
        <Card className="hover-lift transition-smooth">
          <CardContent className="p-4">
            <h4 className="font-semibold mb-3 flex items-center gap-2">
              <Calendar className="h-4 w-4 text-primary" />
              Calendario de Proyectos
            </h4>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span>15 Ene - Campaña Social</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <div className="w-2 h-2 bg-accent rounded-full"></div>
                <span>20 Ene - Diseño Logo</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <div className="w-2 h-2 bg-secondary rounded-full"></div>
                <span>25 Ene - Brief Cliente</span>
              </div>
            </div>
            <Button variant="link" className="mt-3 w-full text-sm p-0" data-testid="button-add-event">
              + Agregar evento
            </Button>
          </CardContent>
        </Card>

        {/* Goals & Objectives */}
        <Card className="hover-lift transition-smooth">
          <CardContent className="p-4">
            <h4 className="font-semibold mb-3 flex items-center gap-2">
              <Target className="h-4 w-4 text-accent" />
              Metas y Objetivos
            </h4>
            <div className="space-y-3">
              {goals.map((goal) => (
                <div key={goal.id}>
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span>{goal.title}</span>
                    <span className="text-muted-foreground">{goal.current}/{goal.total}</span>
                  </div>
                  <div className="progress-bar">
                    <div 
                      className="progress-fill" 
                      style={{ width: `${(goal.current / goal.total) * 100}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Creative Diary */}
        <Card className="hover-lift transition-smooth">
          <CardContent className="p-4">
            <h4 className="font-semibold mb-3 flex items-center gap-2">
              <BookOpen className="h-4 w-4 text-secondary" />
              Diario Creativo
            </h4>
            <Textarea
              value={diaryEntry}
              onChange={(e) => setDiaryEntry(e.target.value)}
              className="min-h-24 resize-none"
              placeholder="Escribe tus pensamientos del día..."
              data-testid="textarea-diary"
            />
            <Button variant="link" className="mt-2 text-sm p-0" data-testid="button-save-diary">
              💾 Guardar entrada
            </Button>
          </CardContent>
        </Card>

        {/* Color Palette of the Day */}
        <Card className="hover-lift transition-smooth">
          <CardContent className="p-4">
            <h4 className="font-semibold mb-3 flex items-center gap-2">
              <Palette className="h-4 w-4 text-primary" />
              Paleta del Día
            </h4>
            <div className="grid grid-cols-5 gap-2">
              {colors.map((color, index) => (
                <div key={index} className="space-y-1">
                  <div 
                    className="color-swatch cursor-pointer" 
                    style={{ backgroundColor: color.hex }}
                    onClick={() => copyColor(color.hex)}
                    title={`Copiar ${color.name}`}
                    data-testid={`color-swatch-${index}`}
                  ></div>
                  <p className="text-xs text-center text-muted-foreground font-mono">
                    {color.hex}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Progress Widget */}
        <Card className="bg-gradient-to-br from-primary to-accent text-foreground shadow-lg">
          <CardContent className="p-4">
            <h4 className="font-semibold mb-2 flex items-center gap-2">
              <span>⭐</span>
              Progreso Creativo
            </h4>
            <p className="text-sm font-accent mb-3">
              "¡Vas increíble! Cada día eres más brillante ✨"
            </p>
            <div className="progress-bar bg-white/30">
              <div className="progress-fill" style={{ width: '75%', background: 'white' }}></div>
            </div>
            <p className="text-xs mt-2 text-center">75% del camino recorrido</p>
          </CardContent>
        </Card>
      </div>
    </aside>
  );
}
