import { useState } from 'react';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { PieChart, FileText, Target, FolderOpen, Download, Trash2 } from 'lucide-react';

interface ProjectBrief {
  name: string;
  client: string;
  objective: string;
  targetAudience: string;
  startDate: string;
  endDate: string;
  deliverables: string;
}

interface ValueProposition {
  customerSegment: string;
  customerJobs: string;
  frustrations: string;
  joys: string;
  products: string;
  frustrationRelievers: string;
  joyCreators: string;
}

interface SwotAnalysis {
  strengths: string;
  opportunities: string;
  weaknesses: string;
  threats: string;
}

interface Resource {
  id: string;
  name: string;
  type: string;
  size?: string;
  tags: string[];
  url?: string;
}

export default function Projects() {
  const [projectBrief, setProjectBrief] = useLocalStorage<ProjectBrief>('projectBrief', {
    name: '',
    client: '',
    objective: '',
    targetAudience: '',
    startDate: '',
    endDate: '',
    deliverables: ''
  });

  const [valueProposition, setValueProposition] = useLocalStorage<ValueProposition>('valueProposition', {
    customerSegment: '',
    customerJobs: '',
    frustrations: '',
    joys: '',
    products: '',
    frustrationRelievers: '',
    joyCreators: ''
  });

  const [swotAnalysis, setSwotAnalysis] = useLocalStorage<SwotAnalysis>('swotAnalysis', {
    strengths: '',
    opportunities: '',
    weaknesses: '',
    threats: ''
  });

  const [resources, setResources] = useLocalStorage<Resource[]>('projectResources', [
    { id: '1', name: 'Guía de Estilo.pdf', type: 'PDF', size: '2.4 MB', tags: ['Branding'] },
    { id: '2', name: 'Logo_final.png', type: 'Imagen', size: '876 KB', tags: ['Diseño'] },
    { id: '3', name: 'Propuesta_Cliente.docx', type: 'Documento', size: '1.2 MB', tags: ['Documentos'] }
  ]);

  const [searchTerm, setSearchTerm] = useState('');

  const filteredResources = resources.filter(resource =>
    resource.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    resource.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const getFileIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'pdf':
        return '📄';
      case 'imagen':
        return '🖼️';
      case 'documento':
        return '📝';
      default:
        return '📎';
    }
  };

  const getTagColor = (tag: string) => {
    const colors = {
      'Branding': 'bg-primary/20 text-primary',
      'Diseño': 'bg-accent/20 text-accent',
      'Documentos': 'bg-secondary/20 text-secondary'
    };
    return colors[tag as keyof typeof colors] || 'bg-muted text-muted-foreground';
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Value Proposition Canvas */}
      <Card className="glass rounded-xl hover-lift">
        <CardContent className="p-6">
          <h3 className="text-xl font-serif font-bold mb-4 flex items-center gap-2">
            <PieChart className="h-5 w-5 text-primary" />
            Canvas de Propuesta de Valor
          </h3>
          <div className="space-y-4">
            <div>
              <Label htmlFor="customer-segment">Segmento de Cliente</Label>
              <Input
                id="customer-segment"
                value={valueProposition.customerSegment}
                onChange={(e) => setValueProposition(prev => ({ ...prev, customerSegment: e.target.value }))}
                placeholder="Define tu cliente ideal..."
                data-testid="input-customer-segment"
              />
            </div>
            <div>
              <Label htmlFor="customer-jobs">Trabajos del Cliente</Label>
              <Textarea
                id="customer-jobs"
                value={valueProposition.customerJobs}
                onChange={(e) => setValueProposition(prev => ({ ...prev, customerJobs: e.target.value }))}
                className="h-20 resize-none"
                placeholder="¿Qué necesita lograr tu cliente?"
                data-testid="textarea-customer-jobs"
              />
            </div>
            <div>
              <Label htmlFor="value-proposition">Propuesta de Valor</Label>
              <Textarea
                id="value-proposition"
                value={valueProposition.products}
                onChange={(e) => setValueProposition(prev => ({ ...prev, products: e.target.value }))}
                className="h-20 resize-none"
                placeholder="¿Cómo resuelves sus problemas?"
                data-testid="textarea-value-proposition"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Project Brief */}
      <Card className="glass rounded-xl hover-lift">
        <CardContent className="p-6">
          <h3 className="text-xl font-serif font-bold mb-4 flex items-center gap-2">
            <FileText className="h-5 w-5 text-accent" />
            Brief de Proyecto
          </h3>
          <div className="space-y-4">
            <div>
              <Label htmlFor="project-name">Nombre del Proyecto</Label>
              <Input
                id="project-name"
                value={projectBrief.name}
                onChange={(e) => setProjectBrief(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Ej: Campaña Primavera 2024"
                data-testid="input-project-name"
              />
            </div>
            <div>
              <Label htmlFor="project-objective">Objetivo</Label>
              <Textarea
                id="project-objective"
                value={projectBrief.objective}
                onChange={(e) => setProjectBrief(prev => ({ ...prev, objective: e.target.value }))}
                className="h-20 resize-none"
                placeholder="¿Qué quieres lograr?"
                data-testid="textarea-project-objective"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="start-date">Fecha Inicio</Label>
                <Input
                  id="start-date"
                  type="date"
                  value={projectBrief.startDate}
                  onChange={(e) => setProjectBrief(prev => ({ ...prev, startDate: e.target.value }))}
                  data-testid="input-start-date"
                />
              </div>
              <div>
                <Label htmlFor="end-date">Fecha Fin</Label>
                <Input
                  id="end-date"
                  type="date"
                  value={projectBrief.endDate}
                  onChange={(e) => setProjectBrief(prev => ({ ...prev, endDate: e.target.value }))}
                  data-testid="input-end-date"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* SWOT Analysis */}
      <Card className="glass rounded-xl hover-lift">
        <CardContent className="p-6">
          <h3 className="text-xl font-serif font-bold mb-4 flex items-center gap-2">
            <Target className="h-5 w-5 text-secondary" />
            Análisis FODA/SWOT Visual
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
              <h4 className="font-semibold text-green-700 dark:text-green-400 mb-2">Fortalezas</h4>
              <Textarea
                value={swotAnalysis.strengths}
                onChange={(e) => setSwotAnalysis(prev => ({ ...prev, strengths: e.target.value }))}
                className="h-24 resize-none bg-white/50 dark:bg-black/20"
                placeholder="Lista tus fortalezas..."
                data-testid="textarea-strengths"
              />
            </div>
            <div className="bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-lg">
              <h4 className="font-semibold text-yellow-700 dark:text-yellow-400 mb-2">Oportunidades</h4>
              <Textarea
                value={swotAnalysis.opportunities}
                onChange={(e) => setSwotAnalysis(prev => ({ ...prev, opportunities: e.target.value }))}
                className="h-24 resize-none bg-white/50 dark:bg-black/20"
                placeholder="Lista oportunidades..."
                data-testid="textarea-opportunities"
              />
            </div>
            <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-lg">
              <h4 className="font-semibold text-red-700 dark:text-red-400 mb-2">Debilidades</h4>
              <Textarea
                value={swotAnalysis.weaknesses}
                onChange={(e) => setSwotAnalysis(prev => ({ ...prev, weaknesses: e.target.value }))}
                className="h-24 resize-none bg-white/50 dark:bg-black/20"
                placeholder="Lista debilidades..."
                data-testid="textarea-weaknesses"
              />
            </div>
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
              <h4 className="font-semibold text-blue-700 dark:text-blue-400 mb-2">Amenazas</h4>
              <Textarea
                value={swotAnalysis.threats}
                onChange={(e) => setSwotAnalysis(prev => ({ ...prev, threats: e.target.value }))}
                className="h-24 resize-none bg-white/50 dark:bg-black/20"
                placeholder="Lista amenazas..."
                data-testid="textarea-threats"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Resource Library */}
      <Card className="glass rounded-xl hover-lift">
        <CardContent className="p-6">
          <h3 className="text-xl font-serif font-bold mb-4 flex items-center gap-2">
            <FolderOpen className="h-5 w-5 text-primary" />
            Biblioteca de Recursos
          </h3>
          <div className="mb-4">
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="🔍 Buscar recursos..."
              data-testid="input-search-resources"
            />
          </div>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {filteredResources.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <div className="text-2xl mb-2">📂</div>
                <p>No se encontraron recursos</p>
              </div>
            ) : (
              filteredResources.map((resource) => (
                <div key={resource.id} className="flex items-center justify-between p-3 bg-card rounded-lg hover:bg-muted transition-smooth">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{getFileIcon(resource.type)}</span>
                    <div>
                      <p className="font-medium text-sm">{resource.name}</p>
                      {resource.size && (
                        <p className="text-xs text-muted-foreground">{resource.size}</p>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-1 flex-wrap">
                    {resource.tags.map((tag, index) => (
                      <Badge key={index} className={`text-xs ${getTagColor(tag)}`}>
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-1">
                    <Button variant="outline" size="icon" className="h-8 w-8" data-testid={`button-download-${resource.id}`}>
                      <Download className="h-3 w-3" />
                    </Button>
                    <Button variant="outline" size="icon" className="h-8 w-8" data-testid={`button-delete-resource-${resource.id}`}>
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
          <Button className="mt-4 w-full" data-testid="button-add-resource">
            <FolderOpen className="w-4 h-4 mr-2" />
            Agregar Recurso
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
