import { useState } from 'react';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Plus, Eye, Trash2, Upload } from 'lucide-react';

interface MoodBoardImage {
  id: string;
  url: string;
  alt: string;
  project: string;
  tags: string[];
  position?: { x: number; y: number };
}

const PROJECTS = ['Todos los proyectos', 'Proyecto A', 'Proyecto B', 'Marca Personal', 'General'];

export default function MoodBoard() {
  const [images, setImages] = useLocalStorage<MoodBoardImage[]>('moodBoardImages', []);
  const [selectedProject, setSelectedProject] = useLocalStorage('selectedMoodProject', 'Todos los proyectos');
  const [draggedImage, setDraggedImage] = useState<string | null>(null);

  const filteredImages = selectedProject === 'Todos los proyectos' 
    ? images 
    : images.filter(img => img.project === selectedProject);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onload = (event) => {
          if (event.target?.result) {
            const newImage: MoodBoardImage = {
              id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
              url: event.target.result as string,
              alt: file.name,
              project: selectedProject === 'Todos los proyectos' ? 'General' : selectedProject,
              tags: [],
              position: { x: 0, y: 0 }
            };
            setImages(prev => [...prev, newImage]);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const handleDragStart = (e: React.DragEvent, imageId: string) => {
    e.dataTransfer.effectAllowed = 'move';
    setDraggedImage(imageId);
  };

  const handleDragEnd = () => {
    setDraggedImage(null);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (draggedImage) {
      const rect = e.currentTarget.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      setImages(prev => prev.map(img => 
        img.id === draggedImage 
          ? { ...img, position: { x, y } }
          : img
      ));
    }
  };

  const deleteImage = (id: string) => {
    setImages(prev => prev.filter(img => img.id !== id));
  };

  const getProjectColor = (project: string) => {
    const colors = {
      'Proyecto A': 'bg-primary',
      'Proyecto B': 'bg-secondary',
      'Marca Personal': 'bg-accent',
      'General': 'bg-muted-foreground'
    };
    return colors[project as keyof typeof colors] || 'bg-muted-foreground';
  };

  return (
    <Card className="glass rounded-xl">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-serif font-bold">Mood Board Personal</h2>
          <div className="flex gap-2">
            <Select value={selectedProject} onValueChange={setSelectedProject}>
              <SelectTrigger className="w-48" data-testid="select-project">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {PROJECTS.map(project => (
                  <SelectItem key={project} value={project}>
                    {project}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <div>
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={handleImageUpload}
                className="hidden"
                id="mood-image-upload"
                data-testid="input-mood-image-upload"
              />
              <Button asChild className="hover-lift" data-testid="button-add-mood-image">
                <label htmlFor="mood-image-upload" className="cursor-pointer">
                  <Plus className="w-4 h-4 mr-2" />
                  Agregar Imagen
                </label>
              </Button>
            </div>
          </div>
        </div>

        {/* Drag & Drop Area */}
        <div 
          className="drop-zone rounded-xl p-8 mb-6 text-center min-h-48"
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          <Upload className="h-16 w-16 text-muted-foreground mb-4 mx-auto" />
          <h3 className="text-xl font-semibold mb-2">Arrastra y suelta tus imágenes aquí</h3>
          <p className="text-muted-foreground mb-2">o haz clic para seleccionar archivos</p>
          <p className="text-sm text-muted-foreground">Soporta: JPG, PNG, GIF, WEBP</p>
        </div>

        {/* Mood Board Grid */}
        {filteredImages.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <div className="text-4xl mb-4">🖼️</div>
            <p>No hay imágenes en este mood board</p>
            <p className="text-sm">Agrega algunas imágenes para empezar</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredImages.map((image) => (
              <div
                key={image.id}
                className="image-card group"
                draggable
                onDragStart={(e) => handleDragStart(e, image.id)}
                onDragEnd={handleDragEnd}
                data-testid={`mood-image-${image.id}`}
              >
                <img 
                  src={image.url} 
                  alt={image.alt}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-smooth flex items-center justify-center gap-2">
                  <Button size="icon" variant="secondary" className="rounded-full">
                    <Eye className="h-4 w-4" />
                  </Button>
                  <Button 
                    size="icon" 
                    variant="secondary" 
                    className="rounded-full"
                    onClick={() => deleteImage(image.id)}
                    data-testid={`button-delete-mood-${image.id}`}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                <div className="absolute bottom-2 left-2 right-2">
                  <Badge 
                    className={`text-white text-xs ${getProjectColor(image.project)}`}
                  >
                    {image.project}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
