import { useState } from 'react';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, Heart, Plus, Search } from 'lucide-react';

interface FontFamily {
  id: string;
  name: string;
  categories: string[];
  googleFontsUrl: string;
  description: string;
  isFavorite: boolean;
}

const DEFAULT_FONTS: FontFamily[] = [
  {
    id: '1',
    name: 'Playfair Display',
    categories: ['Elegante', 'Serif'],
    googleFontsUrl: 'https://fonts.google.com/specimen/Playfair+Display',
    description: 'Perfecta para títulos elegantes y sofisticados',
    isFavorite: true
  },
  {
    id: '2',
    name: 'Inter',
    categories: ['Moderna', 'Sans-serif'],
    googleFontsUrl: 'https://fonts.google.com/specimen/Inter',
    description: 'Ideal para textos largos y interfaces',
    isFavorite: false
  },
  {
    id: '3',
    name: 'Quicksand',
    categories: ['Bold', 'Display'],
    googleFontsUrl: 'https://fonts.google.com/specimen/Quicksand',
    description: 'Perfecta para títulos impactantes',
    isFavorite: true
  },
  {
    id: '4',
    name: 'Pacifico',
    categories: ['Script', 'Romántica'],
    googleFontsUrl: 'https://fonts.google.com/specimen/Pacifico',
    description: 'Ideal para detalles románticos y especiales',
    isFavorite: true
  },
  {
    id: '5',
    name: 'Montserrat',
    categories: ['Moderna', 'Versátil'],
    googleFontsUrl: 'https://fonts.google.com/specimen/Montserrat',
    description: 'Excelente para branding y títulos',
    isFavorite: false
  },
  {
    id: '6',
    name: 'Lora',
    categories: ['Elegante', 'Serif'],
    googleFontsUrl: 'https://fonts.google.com/specimen/Lora',
    description: 'Perfecta para textos largos con elegancia',
    isFavorite: false
  }
];

const CATEGORIES = ['Todas', 'Elegante', 'Moderna', 'Bold', 'Script', 'Sans-serif', 'Serif', 'Display', 'Romántica', 'Versátil'];

export default function Typography() {
  const [fonts, setFonts] = useLocalStorage<FontFamily[]>('fontLibrary', DEFAULT_FONTS);
  const [selectedCategory, setSelectedCategory] = useState('Todas');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredFonts = fonts.filter(font => {
    const matchesCategory = selectedCategory === 'Todas' || font.categories.includes(selectedCategory);
    const matchesSearch = font.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         font.categories.some(cat => cat.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const toggleFavorite = (id: string) => {
    setFonts(prev => prev.map(font => 
      font.id === id ? { ...font, isFavorite: !font.isFavorite } : font
    ));
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'Elegante': 'bg-primary/20 text-primary',
      'Moderna': 'bg-secondary/20 text-secondary',
      'Bold': 'bg-accent/20 text-accent',
      'Script': 'bg-pink-500/20 text-pink-700 dark:text-pink-400',
      'Serif': 'bg-blue-500/20 text-blue-700 dark:text-blue-400',
      'Sans-serif': 'bg-green-500/20 text-green-700 dark:text-green-400',
      'Display': 'bg-purple-500/20 text-purple-700 dark:text-purple-400',
      'Romántica': 'bg-rose-500/20 text-rose-700 dark:text-rose-400',
      'Versátil': 'bg-orange-500/20 text-orange-700 dark:text-orange-400'
    };
    return colors[category] || 'bg-muted text-muted-foreground';
  };

  const getFontStyle = (fontName: string) => {
    const fontMap: Record<string, string> = {
      'Playfair Display': 'font-serif',
      'Inter': 'font-sans',
      'Quicksand': 'font-accent',
      'Pacifico': 'font-romantic',
      'Montserrat': 'font-sans',
      'Lora': 'font-serif'
    };
    return fontMap[fontName] || 'font-sans';
  };

  return (
    <Card className="glass rounded-xl">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-serif font-bold flex items-center gap-2">
            🔤 Banco de Tipografías
          </h3>
          <Button className="hover-lift" data-testid="button-add-font">
            <Plus className="w-4 h-4 mr-2" />
            Agregar Fuente
          </Button>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar fuentes..."
              className="pl-10"
              data-testid="input-search-fonts"
            />
          </div>
          
          {/* Category Filter */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            {CATEGORIES.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="whitespace-nowrap transition-smooth"
                data-testid={`button-category-${category.toLowerCase()}`}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Font Grid */}
        {filteredFonts.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <div className="text-4xl mb-4">🔤</div>
            <p>No se encontraron fuentes</p>
            <p className="text-sm">Intenta con otros términos de búsqueda</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredFonts.map((font) => (
              <Card key={font.id} className="hover-lift transition-smooth">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h4 className={`text-3xl mb-2 ${getFontStyle(font.name)}`}>
                        {font.name}
                      </h4>
                      <p className="text-sm text-muted-foreground mb-3">
                        {font.description}
                      </p>
                      <div className="flex flex-wrap gap-2 mb-3">
                        {font.categories.map((category, index) => (
                          <Badge 
                            key={index} 
                            className={`text-xs ${getCategoryColor(category)}`}
                          >
                            {category}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex gap-2 ml-4">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => toggleFavorite(font.id)}
                        className={`transition-smooth ${font.isFavorite ? 'text-red-500 hover:text-red-600' : 'text-muted-foreground hover:text-red-500'}`}
                        data-testid={`button-favorite-font-${font.id}`}
                      >
                        <Heart className={`h-4 w-4 ${font.isFavorite ? 'fill-current' : ''}`} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        asChild
                        data-testid={`button-view-font-${font.id}`}
                      >
                        <a href={font.googleFontsUrl} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      </Button>
                    </div>
                  </div>
                  
                  {/* Font Preview */}
                  <div className={`space-y-2 ${getFontStyle(font.name)}`}>
                    <p className="text-2xl font-bold">
                      The Quick Brown Fox
                    </p>
                    <p className="text-lg">
                      Jumps Over The Lazy Dog
                    </p>
                    <p className="text-sm text-muted-foreground">
                      ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz 0123456789
                    </p>
                  </div>

                  {/* Usage Suggestions */}
                  <div className="mt-4 pt-4 border-t border-border">
                    <p className="text-xs text-muted-foreground">
                      <strong>Uso sugerido:</strong> {getUsageSuggestion(font.categories)}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Favorites Section */}
        {fonts.some(font => font.isFavorite) && (
          <div className="mt-8 pt-6 border-t border-border">
            <h4 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Heart className="h-5 w-5 text-red-500 fill-current" />
              Fuentes Favoritas
            </h4>
            <div className="flex flex-wrap gap-2">
              {fonts.filter(font => font.isFavorite).map(font => (
                <Badge 
                  key={font.id} 
                  variant="outline" 
                  className="px-3 py-1 cursor-pointer hover:bg-primary hover:text-primary-foreground transition-smooth"
                  onClick={() => setSearchTerm(font.name)}
                  data-testid={`badge-favorite-${font.id}`}
                >
                  {font.name}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function getUsageSuggestion(categories: string[]): string {
  const suggestions: Record<string, string> = {
    'Elegante': 'Títulos sofisticados, invitaciones, branding de lujo',
    'Moderna': 'Interfaces web, textos corporativos, aplicaciones',
    'Bold': 'Títulos impactantes, carteles, headers principales',
    'Script': 'Detalles decorativos, firmas, elementos románticos',
    'Serif': 'Textos largos, publicaciones editoriales, blogs',
    'Sans-serif': 'Interfaces, textos funcionales, etiquetas',
    'Display': 'Títulos grandes, logotipos, elementos decorativos',
    'Romántica': 'Invitaciones, tarjetas, detalles especiales',
    'Versátil': 'Múltiples usos, sistemas de diseño, branding'
  };

  for (const category of categories) {
    if (suggestions[category]) {
      return suggestions[category];
    }
  }
  
  return 'Uso general en proyectos de diseño';
}
