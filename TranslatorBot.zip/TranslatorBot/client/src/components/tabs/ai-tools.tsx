import { useState } from 'react';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { MessageCircle, Sparkles, Image as ImageIcon, Send, Bot } from 'lucide-react';
import { sendChatMessage, generateBranding, generateImage, type ChatMessage, type BrandingResponse } from '@/lib/gemini';

export default function AITools() {
  const [chatHistory, setChatHistory] = useLocalStorage<ChatMessage[]>('chatHistory', [
    { role: 'assistant', content: '¡Hola! Soy Gemini, tu asistente creativo. ¿En qué puedo ayudarte hoy?' }
  ]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  // Branding generator state
  const [brandingForm, setBrandingForm] = useState({
    industry: '',
    values: '',
    target: ''
  });
  const [brandingResult, setBrandingResult] = useState<BrandingResponse | null>(null);
  const [isBrandingLoading, setIsBrandingLoading] = useState(false);
  
  // Image generator state
  const [imagePrompt, setImagePrompt] = useState('');
  const [imageStyle, setImageStyle] = useState('Fotográfico');
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isImageLoading, setIsImageLoading] = useState(false);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentMessage.trim() || isLoading) return;

    const userMessage = currentMessage.trim();
    setCurrentMessage('');
    setIsLoading(true);

    const newUserMessage: ChatMessage = { role: 'user', content: userMessage };
    setChatHistory(prev => [...prev, newUserMessage]);

    try {
      const response = await sendChatMessage(userMessage, chatHistory);
      const assistantMessage: ChatMessage = { role: 'assistant', content: response };
      setChatHistory(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage: ChatMessage = { 
        role: 'assistant', 
        content: 'Lo siento, ocurrió un error. Por favor intenta de nuevo.' 
      };
      setChatHistory(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateBranding = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!brandingForm.industry || !brandingForm.values || isBrandingLoading) return;

    setIsBrandingLoading(true);
    try {
      const result = await generateBranding(
        brandingForm.industry,
        brandingForm.values,
        brandingForm.target
      );
      setBrandingResult(result);
    } catch (error) {
      console.error('Error generating branding:', error);
    } finally {
      setIsBrandingLoading(false);
    }
  };

  const handleGenerateImage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!imagePrompt.trim() || isImageLoading) return;

    setIsImageLoading(true);
    try {
      const image = await generateImage(imagePrompt, imageStyle);
      setGeneratedImage(image);
    } catch (error) {
      console.error('Error generating image:', error);
      setGeneratedImage(null);
    } finally {
      setIsImageLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Gemini Chat */}
      <Card className="glass rounded-xl lg:col-span-2">
        <CardContent className="p-6">
          <h3 className="text-xl font-serif font-bold mb-4 flex items-center gap-2">
            <MessageCircle className="h-5 w-5 text-primary" />
            Chat con Gemini AI
          </h3>
          <div className="bg-card rounded-lg h-96 overflow-y-auto p-4 mb-4 space-y-4">
            {chatHistory.map((message, index) => (
              <div key={index} className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : ''}`}>
                {message.role === 'assistant' && (
                  <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center flex-shrink-0">
                    <Bot className="h-4 w-4 text-white" />
                  </div>
                )}
                <div className={`rounded-lg p-3 max-w-md ${
                  message.role === 'user' 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-muted'
                }`}>
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                </div>
                {message.role === 'user' && (
                  <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-white text-sm font-bold">G</span>
                  </div>
                )}
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-3">
                <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center flex-shrink-0">
                  <Bot className="h-4 w-4 text-white" />
                </div>
                <div className="bg-muted rounded-lg p-3 max-w-md">
                  <p className="text-sm">Escribiendo...</p>
                </div>
              </div>
            )}
          </div>
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <Input
              value={currentMessage}
              onChange={(e) => setCurrentMessage(e.target.value)}
              placeholder="Escribe tu mensaje..."
              disabled={isLoading}
              data-testid="input-chat-message"
            />
            <Button type="submit" disabled={isLoading || !currentMessage.trim()} data-testid="button-send-message">
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Branding Generator */}
        <Card className="glass rounded-xl hover-lift">
          <CardContent className="p-6">
            <h3 className="text-xl font-serif font-bold mb-4 flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-accent" />
              Generador de Branding
            </h3>
            <form onSubmit={handleGenerateBranding} className="space-y-4">
              <div>
                <Label htmlFor="industry">Industria/Sector</Label>
                <Input
                  id="industry"
                  value={brandingForm.industry}
                  onChange={(e) => setBrandingForm(prev => ({ ...prev, industry: e.target.value }))}
                  placeholder="Ej: Moda sostenible"
                  data-testid="input-branding-industry"
                />
              </div>
              <div>
                <Label htmlFor="values">Valores de Marca</Label>
                <Input
                  id="values"
                  value={brandingForm.values}
                  onChange={(e) => setBrandingForm(prev => ({ ...prev, values: e.target.value }))}
                  placeholder="Ej: Elegancia, naturaleza, innovación"
                  data-testid="input-branding-values"
                />
              </div>
              <div>
                <Label htmlFor="target">Público Objetivo</Label>
                <Input
                  id="target"
                  value={brandingForm.target}
                  onChange={(e) => setBrandingForm(prev => ({ ...prev, target: e.target.value }))}
                  placeholder="Ej: Jóvenes profesionales 25-40"
                  data-testid="input-branding-target"
                />
              </div>
              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-primary to-accent font-semibold"
                disabled={isBrandingLoading || !brandingForm.industry || !brandingForm.values}
                data-testid="button-generate-branding"
              >
                {isBrandingLoading ? 'Generando...' : '✨ Generar Ideas de Branding'}
              </Button>
            </form>
            
            {brandingResult && (
              <div className="mt-4 p-4 bg-card rounded-lg space-y-3">
                <div>
                  <h4 className="font-semibold mb-2">Nombres Sugeridos:</h4>
                  <div className="flex flex-wrap gap-2">
                    {brandingResult.names.map((name, index) => (
                      <Badge key={index} variant="secondary" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
                        {name}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Slogans:</h4>
                  {brandingResult.slogans.map((slogan, index) => (
                    <p key={index} className="text-sm text-muted-foreground italic mb-1">"{slogan}"</p>
                  ))}
                </div>
                {brandingResult.concepts && (
                  <div>
                    <h4 className="font-semibold mb-2">Conceptos:</h4>
                    <p className="text-sm text-muted-foreground">{brandingResult.concepts}</p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Image Generator */}
        <Card className="glass rounded-xl hover-lift">
          <CardContent className="p-6">
            <h3 className="text-xl font-serif font-bold mb-4 flex items-center gap-2">
              <ImageIcon className="h-5 w-5 text-secondary" />
              Generador de Imágenes
            </h3>
            <form onSubmit={handleGenerateImage} className="space-y-4">
              <div>
                <Label htmlFor="image-prompt">Descripción de la Imagen</Label>
                <Textarea
                  id="image-prompt"
                  value={imagePrompt}
                  onChange={(e) => setImagePrompt(e.target.value)}
                  className="h-24 resize-none"
                  placeholder="Describe la imagen que deseas generar..."
                  data-testid="textarea-image-prompt"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="image-style">Estilo</Label>
                  <Select value={imageStyle} onValueChange={setImageStyle}>
                    <SelectTrigger data-testid="select-image-style">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Fotográfico">Realista</SelectItem>
                      <SelectItem value="Arte Digital">Arte Digital</SelectItem>
                      <SelectItem value="Ilustración">Ilustración</SelectItem>
                      <SelectItem value="Minimalista">Minimalista</SelectItem>
                      <SelectItem value="Abstracto">Abstracto</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end">
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-secondary to-primary font-semibold"
                    disabled={isImageLoading || !imagePrompt.trim()}
                    data-testid="button-generate-image"
                  >
                    {isImageLoading ? 'Generando...' : '🎨 Generar Imagen'}
                  </Button>
                </div>
              </div>
            </form>
            
            <div className="mt-4 aspect-square bg-card rounded-lg flex items-center justify-center">
              {isImageLoading ? (
                <div className="text-center">
                  <div className="animate-spin text-4xl mb-2">🎨</div>
                  <p className="text-sm text-muted-foreground">Generando imagen...</p>
                </div>
              ) : generatedImage ? (
                <img src={generatedImage} alt="Generated" className="w-full h-full object-cover rounded-lg" />
              ) : (
                <div className="text-center text-muted-foreground">
                  <ImageIcon className="h-16 w-16 mx-auto mb-2" />
                  <p className="text-sm">La imagen generada aparecerá aquí</p>
                </div>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-2 text-center">
              Utiliza API de Gemini para generación de imágenes
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
