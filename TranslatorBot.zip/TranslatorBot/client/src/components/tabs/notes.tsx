import { useState, useRef, useEffect } from 'react';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Plus, Search, Trash2, Download, Share2, Bold, Italic, Underline, List, ListOrdered, Link, Image as ImageIcon, Clock } from 'lucide-react';

interface Note {
  id: string;
  title: string;
  content: string;
  category: 'estudios' | 'campañas' | 'personales' | 'ideas' | 'recursos';
  tags: string[];
  createdAt: Date;
  updatedAt: Date;
}

const CATEGORIES = [
  { value: 'all', label: 'Todas las categorías' },
  { value: 'estudios', label: 'Estudios' },
  { value: 'campañas', label: 'Campañas' },
  { value: 'personales', label: 'Personales' },
  { value: 'ideas', label: 'Ideas' },
  { value: 'recursos', label: 'Recursos' }
];

const DEFAULT_NOTES: Note[] = [
  {
    id: '1',
    title: 'Ideas para campaña sostenible',
    content: 'Conceptos principales:\n- Sostenibilidad como valor central\n- Elegancia y naturaleza\n- Paleta de verdes y tonos tierra\n- Fotografía natural y auténtica',
    category: 'campañas',
    tags: ['sostenibilidad', 'branding', 'naturaleza'],
    createdAt: new Date(2024, 0, 15, 10, 30),
    updatedAt: new Date(2024, 0, 15, 14, 45)
  },
  {
    id: '2',
    title: 'Apuntes curso diseño UX',
    content: 'Teoría del color:\n- Complementarios: crean contraste\n- Análogos: armonía visual\n- Triádicos: equilibrio dinámico\n\nPsicología del color:\n- Azul: confianza, profesionalismo\n- Verde: naturaleza, calma\n- Rojo: urgencia, pasión',
    category: 'estudios',
    tags: ['ux', 'color', 'teoría'],
    createdAt: new Date(2024, 0, 14, 9, 0),
    updatedAt: new Date(2024, 0, 14, 11, 30)
  },
  {
    id: '3',
    title: 'Recordatorios importantes',
    content: '- Reunión con cliente el viernes a las 3pm\n- Enviar propuesta de branding antes del lunes\n- Actualizar portfolio con últimos proyectos\n- Comprar materiales para mood board físico',
    category: 'personales',
    tags: ['recordatorios', 'tareas'],
    createdAt: new Date(2024, 0, 13, 16, 15),
    updatedAt: new Date(2024, 0, 13, 16, 45)
  }
];

export default function Notes() {
  const [notes, setNotes] = useLocalStorage<Note[]>('notes', DEFAULT_NOTES);
  const [selectedNote, setSelectedNote] = useState<Note | null>(notes[0] || null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [autoSaveTimer, setAutoSaveTimer] = useState<NodeJS.Timeout | null>(null);

  const titleRef = useRef<HTMLInputElement>(null);
  const contentRef = useRef<HTMLTextAreaElement>(null);

  const filteredNotes = notes.filter(note => {
    const matchesCategory = selectedCategory === 'all' || note.category === selectedCategory;
    const matchesSearch = note.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         note.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         note.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCategory && matchesSearch;
  }).sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

  const handleCreateNew = () => {
    const newNote: Note = {
      id: Date.now().toString(),
      title: 'Nueva nota',
      content: '',
      category: 'personales',
      tags: [],
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    setNotes(prev => [newNote, ...prev]);
    setSelectedNote(newNote);
    setIsCreatingNew(true);
    
    // Focus on title after state update
    setTimeout(() => {
      titleRef.current?.focus();
      titleRef.current?.select();
    }, 100);
  };

  const handleUpdateNote = (field: keyof Note, value: any) => {
    if (!selectedNote) return;

    const updatedNote = {
      ...selectedNote,
      [field]: value,
      updatedAt: new Date()
    };

    setSelectedNote(updatedNote);
    setNotes(prev => prev.map(note => 
      note.id === selectedNote.id ? updatedNote : note
    ));

    // Auto-save after 2 seconds of inactivity
    if (autoSaveTimer) {
      clearTimeout(autoSaveTimer);
    }
    
    const timer = setTimeout(() => {
      // Auto-save is handled by useLocalStorage, just show indicator
      const indicator = document.querySelector('.save-indicator');
      if (!indicator) {
        const toast = document.createElement('div');
        toast.className = 'save-indicator';
        toast.textContent = 'Guardado automático ✓';
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 2000);
      }
    }, 2000);
    
    setAutoSaveTimer(timer);
  };

  const handleDeleteNote = (noteId: string) => {
    if (notes.length <= 1) return; // Keep at least one note
    
    setNotes(prev => prev.filter(note => note.id !== noteId));
    
    if (selectedNote?.id === noteId) {
      const remainingNotes = notes.filter(note => note.id !== noteId);
      setSelectedNote(remainingNotes[0] || null);
    }
  };

  const handleExportNote = () => {
    if (!selectedNote) return;

    const content = `${selectedNote.title}\n\n${selectedNote.content}\n\nCategoría: ${selectedNote.category}\nEtiquetas: ${selectedNote.tags.join(', ')}\n\nCreado: ${selectedNote.createdAt.toLocaleString('es-ES')}\nActualizado: ${selectedNote.updatedAt.toLocaleString('es-ES')}`;
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedNote.title.replace(/[^a-z0-9]/gi, '_')}.txt`;
    a.click();
    URL.revokeObjectURL(url);

    const toast = document.createElement('div');
    toast.className = 'save-indicator';
    toast.textContent = 'Nota exportada 📄';
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2000);
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      'estudios': 'bg-blue-500/20 text-blue-700 dark:text-blue-400',
      'campañas': 'bg-green-500/20 text-green-700 dark:text-green-400',
      'personales': 'bg-purple-500/20 text-purple-700 dark:text-purple-400',
      'ideas': 'bg-yellow-500/20 text-yellow-700 dark:text-yellow-400',
      'recursos': 'bg-pink-500/20 text-pink-700 dark:text-pink-400'
    };
    return colors[category as keyof typeof colors] || 'bg-muted text-muted-foreground';
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor(diff / (1000 * 60));

    if (days > 0) return `Hace ${days} día${days > 1 ? 's' : ''}`;
    if (hours > 0) return `Hace ${hours} hora${hours > 1 ? 's' : ''}`;
    if (minutes > 0) return `Hace ${minutes} minuto${minutes > 1 ? 's' : ''}`;
    return 'Ahora mismo';
  };

  useEffect(() => {
    return () => {
      if (autoSaveTimer) {
        clearTimeout(autoSaveTimer);
      }
    };
  }, [autoSaveTimer]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Notes List */}
      <div className="lg:col-span-1 glass rounded-xl">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-serif font-bold">Mis Notas</h3>
            <Button 
              size="icon" 
              onClick={handleCreateNew}
              className="rounded-full hover-lift"
              data-testid="button-create-note"
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          {/* Search */}
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar notas..."
              className="pl-10"
              data-testid="input-search-notes"
            />
          </div>

          {/* Category Filter */}
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="mb-4" data-testid="select-note-category">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {CATEGORIES.map(category => (
                <SelectItem key={category.value} value={category.value}>
                  {category.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Notes List */}
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {filteredNotes.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <div className="text-2xl mb-2">📝</div>
                <p className="text-sm">No hay notas</p>
                <p className="text-xs">Crea tu primera nota</p>
              </div>
            ) : (
              filteredNotes.map((note) => (
                <Card 
                  key={note.id} 
                  className={`cursor-pointer transition-smooth hover:bg-muted/50 ${
                    selectedNote?.id === note.id ? 'ring-2 ring-primary bg-muted/30' : ''
                  }`}
                  onClick={() => setSelectedNote(note)}
                  data-testid={`note-item-${note.id}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold line-clamp-1 flex-1 mr-2">{note.title}</h4>
                      <span className="text-xs text-muted-foreground whitespace-nowrap">
                        {formatDate(note.updatedAt)}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                      {note.content || 'Sin contenido'}
                    </p>
                    <div className="flex items-center justify-between">
                      <Badge className={`text-xs ${getCategoryColor(note.category)}`}>
                        {CATEGORIES.find(cat => cat.value === note.category)?.label || note.category}
                      </Badge>
                      {note.tags.length > 0 && (
                        <span className="text-xs text-muted-foreground">
                          {note.tags.length} etiqueta{note.tags.length > 1 ? 's' : ''}
                        </span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </CardContent>
      </div>

      {/* Note Editor */}
      <div className="lg:col-span-2 glass rounded-xl">
        <CardContent className="p-6">
          {selectedNote ? (
            <>
              {/* Note Header */}
              <div className="mb-4">
                <Input
                  ref={titleRef}
                  value={selectedNote.title}
                  onChange={(e) => handleUpdateNote('title', e.target.value)}
                  className="text-2xl font-serif font-bold bg-transparent border-none outline-none p-0 mb-2"
                  placeholder="Título de la nota..."
                  data-testid="input-note-title"
                />
                <div className="flex gap-2 items-center flex-wrap">
                  <Select 
                    value={selectedNote.category} 
                    onValueChange={(value) => handleUpdateNote('category', value)}
                  >
                    <SelectTrigger className="w-40" data-testid="select-note-category-editor">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.slice(1).map(category => (
                        <SelectItem key={category.value} value={category.value}>
                          {category.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span>Guardado automáticamente</span>
                  </div>
                </div>
              </div>

              {/* Rich Text Toolbar */}
              <div className="flex gap-2 mb-4 pb-4 border-b border-border flex-wrap">
                <Button variant="outline" size="icon" className="h-8 w-8" title="Negrita">
                  <Bold className="h-3 w-3" />
                </Button>
                <Button variant="outline" size="icon" className="h-8 w-8" title="Cursiva">
                  <Italic className="h-3 w-3" />
                </Button>
                <Button variant="outline" size="icon" className="h-8 w-8" title="Subrayado">
                  <Underline className="h-3 w-3" />
                </Button>
                <div className="w-px bg-border"></div>
                <Button variant="outline" size="icon" className="h-8 w-8" title="Lista">
                  <List className="h-3 w-3" />
                </Button>
                <Button variant="outline" size="icon" className="h-8 w-8" title="Lista numerada">
                  <ListOrdered className="h-3 w-3" />
                </Button>
                <div className="w-px bg-border"></div>
                <Button variant="outline" size="icon" className="h-8 w-8" title="Enlace">
                  <Link className="h-3 w-3" />
                </Button>
                <Button variant="outline" size="icon" className="h-8 w-8" title="Imagen">
                  <ImageIcon className="h-3 w-3" />
                </Button>
              </div>

              {/* Note Content */}
              <Textarea
                ref={contentRef}
                value={selectedNote.content}
                onChange={(e) => handleUpdateNote('content', e.target.value)}
                className="h-96 resize-none border-none outline-none p-0 text-base leading-relaxed"
                placeholder="Escribe tus notas aquí... Se guardan automáticamente ✨"
                data-testid="textarea-note-content"
              />

              {/* Note Actions */}
              <div className="mt-4 flex justify-between items-center pt-4 border-t border-border">
                <div className="flex gap-2">
                  <Button 
                    variant="destructive" 
                    size="sm"
                    onClick={() => handleDeleteNote(selectedNote.id)}
                    disabled={notes.length <= 1}
                    data-testid="button-delete-note"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Eliminar
                  </Button>
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleExportNote}
                    data-testid="button-export-note"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Exportar
                  </Button>
                  <Button 
                    size="sm"
                    data-testid="button-share-note"
                  >
                    <Share2 className="w-4 h-4 mr-2" />
                    Compartir
                  </Button>
                </div>
              </div>

              {/* Note Metadata */}
              <div className="mt-4 pt-4 border-t border-border text-xs text-muted-foreground">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <p>Creado: {selectedNote.createdAt.toLocaleDateString('es-ES')} a las {selectedNote.createdAt.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}</p>
                  <p>Última edición: {selectedNote.updatedAt.toLocaleDateString('es-ES')} a las {selectedNote.updatedAt.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}</p>
                </div>
              </div>
            </>
          ) : (
            <div className="text-center py-24 text-muted-foreground">
              <div className="text-6xl mb-4">📝</div>
              <h3 className="text-xl font-semibold mb-2">No hay nota seleccionada</h3>
              <p className="text-sm mb-4">Selecciona una nota de la lista o crea una nueva</p>
              <Button onClick={handleCreateNew} data-testid="button-create-first-note">
                <Plus className="w-4 h-4 mr-2" />
                Crear Primera Nota
              </Button>
            </div>
          )}
        </CardContent>
      </div>
    </div>
  );
}
