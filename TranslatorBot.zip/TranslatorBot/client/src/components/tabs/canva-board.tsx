import { useState } from 'react';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Plus, ExternalLink, Trash2, Upload } from 'lucide-react';

interface CanvaLink {
  id: string;
  title: string;
  url: string;
  thumbnail: string;
  tags: string[];
  notes: string;
  createdAt: Date;
}

interface ReferenceImage {
  id: string;
  url: string;
  alt: string;
  tags: string[];
}

export default function CanvaBoard() {
  const [canvaLinks, setCanvaLinks] = useLocalStorage<CanvaLink[]>('canvaLinks', []);
  const [referenceImages, setReferenceImages] = useLocalStorage<ReferenceImage[]>('referenceImages', []);
  const [notes, setNotes] = useLocalStorage('canvaNotes', '');
  const [isAddingLink, setIsAddingLink] = useState(false);

  const handleAddCanvaLink = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const newLink: CanvaLink = {
      id: Date.now().toString(),
      title: formData.get('title') as string,
      url: formData.get('url') as string,
      thumbnail: formData.get('thumbnail') as string || '/api/placeholder/200/150',
      tags: (formData.get('tags') as string).split(',').map(tag => tag.trim()).filter(Boolean),
      notes: formData.get('linkNotes') as string,
      createdAt: new Date()
    };

    setCanvaLinks(prev => [newLink, ...prev]);
    setIsAddingLink(false);
  };

  const handleDeleteLink = (id: string) => {
    setCanvaLinks(prev => prev.filter(link => link.id !== id));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onload = (event) => {
          if (event.target?.result) {
            const newImage: ReferenceImage = {
              id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
              url: event.target.result as string,
              alt: file.name,
              tags: []
            };
            setReferenceImages(prev => [...prev, newImage]);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Canva Links Section */}
      <div className="lg:col-span-2 space-y-6">
        <Card className="glass rounded-xl">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-serif font-bold">Links de Canva</h2>
              <Dialog open={isAddingLink} onOpenChange={setIsAddingLink}>
                <DialogTrigger asChild>
                  <Button className="hover-lift" data-testid="button-add-canva-link">
                    <Plus className="w-4 h-4 mr-2" />
                    Nuevo Link
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Agregar Link de Canva</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleAddCanvaLink} className="space-y-4">
                    <div>
                      <Label htmlFor="title">Título</Label>
                      <Input id="title" name="title" required data-testid="input-canva-title" />
                    </div>
                    <div>
                      <Label htmlFor="url">URL de Canva</Label>
                      <Input id="url" name="url" type="url" required data-testid="input-canva-url" />
                    </div>
                    <div>
                      <Label htmlFor="thumbnail">URL de miniatura (opcional)</Label>
                      <Input id="thumbnail" name="thumbnail" type="url" data-testid="input-canva-thumbnail" />
                    </div>
                    <div>
                      <Label htmlFor="tags">Etiquetas (separadas por comas)</Label>
                      <Input id="tags" name="tags" placeholder="branding, social media" data-testid="input-canva-tags" />
                    </div>
                    <div>
                      <Label htmlFor="linkNotes">Notas</Label>
                      <Textarea id="linkNotes" name="linkNotes" className="h-20 resize-none" data-testid="textarea-canva-notes" />
                    </div>
                    <div className="flex gap-2">
                      <Button type="submit" className="flex-1" data-testid="button-save-canva-link">
                        Guardar
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setIsAddingLink(false)}>
                        Cancelar
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
            
            <div className="space-y-4">
              {canvaLinks.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <div className="text-4xl mb-4">🎨</div>
                  <p>No hay links de Canva guardados</p>
                  <p className="text-sm">Agrega tu primer diseño para empezar</p>
                </div>
              ) : (
                canvaLinks.map((link) => (
                  <Card key={link.id} className="hover-lift transition-smooth">
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        <img 
                          src={link.thumbnail} 
                          alt={link.title}
                          className="w-32 h-24 object-cover rounded-lg"
                          onError={(e) => {
                            e.currentTarget.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjE1MCIgdmlld0JveD0iMCAwIDIwMCAxNTAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIyMDAiIGhlaWdodD0iMTUwIiBmaWxsPSIjRjNGNEY2Ii8+CjxwYXRoIGQ9Ik04NyA3NUw5MyA4MUw5OSA3NUw5MyA2OUw4NyA3NVoiIGZpbGw9IiM5Q0EzQUYiLz4KPHN0cm9rZSBvcGFjaXR5PSIwLjUiLz4KPC9zdmc+';
                          }}
                        />
                        <div className="flex-1">
                          <h3 className="font-semibold mb-1">{link.title}</h3>
                          <p className="text-sm text-muted-foreground mb-2 truncate">{link.url}</p>
                          {link.notes && (
                            <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{link.notes}</p>
                          )}
                          <div className="flex flex-wrap gap-2 mb-2">
                            {link.tags.map((tag, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex flex-col gap-2">
                          <Button variant="outline" size="icon" asChild data-testid={`button-open-canva-${link.id}`}>
                            <a href={link.url} target="_blank" rel="noopener noreferrer">
                              <ExternalLink className="h-4 w-4" />
                            </a>
                          </Button>
                          <Button 
                            variant="outline" 
                            size="icon" 
                            onClick={() => handleDeleteLink(link.id)}
                            data-testid={`button-delete-canva-${link.id}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Reference Images */}
        <Card className="glass rounded-xl">
          <CardContent className="p-6">
            <h2 className="text-2xl font-serif font-bold mb-4">Imágenes de Referencia</h2>
            <div className="image-grid mb-4">
              {referenceImages.map((image) => (
                <div key={image.id} className="image-card group">
                  <img src={image.url} alt={image.alt} />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-smooth flex items-center justify-center gap-2">
                    <Button size="icon" variant="secondary" className="rounded-full">
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                    <Button 
                      size="icon" 
                      variant="secondary" 
                      className="rounded-full"
                      onClick={() => setReferenceImages(prev => prev.filter(img => img.id !== image.id))}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Upload Area */}
            <div className="drop-zone rounded-xl p-6 text-center">
              <Upload className="h-12 w-12 text-muted-foreground mb-4 mx-auto" />
              <h3 className="text-xl font-semibold mb-2">Arrastra imágenes aquí</h3>
              <p className="text-muted-foreground mb-4">o haz clic para seleccionar archivos</p>
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={handleImageUpload}
                className="hidden"
                id="image-upload"
                data-testid="input-image-upload"
              />
              <Button asChild variant="outline">
                <label htmlFor="image-upload" className="cursor-pointer">
                  Seleccionar Imágenes
                </label>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Notes Section */}
      <div className="lg:col-span-1">
        <Card className="glass rounded-xl sticky top-24">
          <CardContent className="p-6">
            <h3 className="text-xl font-serif font-bold mb-4">
              📝 Campo de Notas
            </h3>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="h-96 resize-none"
              placeholder="Escribe tus ideas, conceptos y notas sobre este proyecto..."
              data-testid="textarea-canva-notes-main"
            />
            <div className="mt-4 flex justify-between items-center">
              <span className="text-xs text-muted-foreground">Guardado automático activado</span>
              <Button 
                variant="link" 
                size="sm"
                onClick={() => navigator.clipboard.writeText(notes)}
                data-testid="button-copy-notes"
              >
                📋 Copiar
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
