import { useLocalStorage } from '@/hooks/use-local-storage';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Star, Plus, ExternalLink } from 'lucide-react';

interface CanvaTemplate {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  category: string;
  isFavorite: boolean;
}

interface Reference {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  category: 'competition' | 'inspiration';
  status: 'high-competition' | 'inspiration';
}

const COLOR_PALETTE = [
  { hex: '#FFB6C1', name: 'Rosa claro', rgb: 'rgb(255,182,193)' },
  { hex: '#FF6B9D', name: 'Rosa vibrante', rgb: 'rgb(255,107,157)' },
  { hex: '#DDA0DD', name: 'Ciruela', rgb: 'rgb(221,160,221)' },
  { hex: '#E6E6FA', name: 'Lavanda', rgb: 'rgb(230,230,250)' },
  { hex: '#FFC0CB', name: 'Rosa pastel', rgb: 'rgb(255,192,203)' },
  { hex: '#FFFAF5', name: 'Blanco nieve', rgb: 'rgb(255,250,245)' }
];

export default function Inspiration() {
  const [templates, setTemplates] = useLocalStorage<CanvaTemplate[]>('canvaTemplates', [
    {
      id: '1',
      title: 'Post Instagram - Minimalista',
      description: 'Perfecto para contenido elegante',
      imageUrl: '/api/placeholder/400/300',
      category: 'Social Media',
      isFavorite: true
    },
    {
      id: '2',
      title: 'Presentación Corporativa',
      description: 'Diseño profesional y moderno',
      imageUrl: '/api/placeholder/400/300',
      category: 'Presentaciones',
      isFavorite: true
    },
    {
      id: '3',
      title: 'Flyer Promocional',
      description: 'Impacto visual garantizado',
      imageUrl: '/api/placeholder/400/300',
      category: 'Marketing',
      isFavorite: false
    }
  ]);

  const [references, setReferences] = useLocalStorage<Reference[]>('competitionReferences', [
    {
      id: '1',
      title: 'Marca Competidora A',
      description: 'Análisis de estrategia visual y mensajes clave',
      imageUrl: '/api/placeholder/150/150',
      category: 'competition',
      status: 'high-competition'
    },
    {
      id: '2',
      title: 'Referencia de Diseño',
      description: 'Inspiración para paleta de colores y tipografía',
      imageUrl: '/api/placeholder/150/150',
      category: 'inspiration',
      status: 'inspiration'
    }
  ]);

  const copyColor = async (color: string) => {
    try {
      await navigator.clipboard.writeText(color);
      const toast = document.createElement('div');
      toast.className = 'save-indicator';
      toast.textContent = `Color ${color} copiado! 🎨`;
      document.body.appendChild(toast);
      setTimeout(() => toast.remove(), 2000);
    } catch (err) {
      console.error('Error copying color:', err);
    }
  };

  const toggleFavorite = (id: string) => {
    setTemplates(prev => prev.map(template =>
      template.id === id ? { ...template, isFavorite: !template.isFavorite } : template
    ));
  };

  const addNewReference = () => {
    const newRef: Reference = {
      id: Date.now().toString(),
      title: 'Nueva Referencia',
      description: 'Descripción de la nueva referencia',
      imageUrl: '/api/placeholder/150/150',
      category: 'inspiration',
      status: 'inspiration'
    };
    setReferences(prev => [...prev, newRef]);
  };

  return (
    <div className="space-y-6">
      {/* Favorite Canva Templates */}
      <Card className="glass rounded-xl">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-serif font-bold flex items-center gap-2">
              <Star className="h-5 w-5 text-yellow-500" />
              Plantillas Favoritas de Canva
            </h3>
            <Button className="hover-lift" data-testid="button-add-template">
              <Plus className="w-4 h-4 mr-2" />
              Agregar Plantilla
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {templates.map((template) => (
              <Card key={template.id} className="hover-lift transition-smooth overflow-hidden">
                <div className="relative">
                  <img 
                    src={template.imageUrl} 
                    alt={template.title}
                    className="w-full h-48 object-cover"
                    onError={(e) => {
                      e.currentTarget.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgdmlld0JveD0iMCAwIDQwMCAzMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSI0MDAiIGhlaWdodD0iMzAwIiBmaWxsPSIjRjNGNEY2Ii8+CjxwYXRoIGQ9Ik0xODcgMTUwTDE5NyAxNjBMMjA3IDE1MEwxOTcgMTQwTDE4NyAxNTBaIiBmaWxsPSIjOUNBM0FGIi8+Cjx0ZXh0IHg9IjIwMCIgeT0iMTcwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmaWxsPSIjOUNBM0FGIiBmb250LXNpemU9IjE0Ij5QbGFudGlsbGE8L3RleHQ+Cjwvc3ZnPg==';
                    }}
                  />
                  <button
                    onClick={() => toggleFavorite(template.id)}
                    className={`absolute top-2 right-2 p-2 rounded-full transition-smooth ${
                      template.isFavorite 
                        ? 'bg-yellow-500 text-white' 
                        : 'bg-white/80 text-gray-600 hover:bg-yellow-500 hover:text-white'
                    }`}
                    data-testid={`button-favorite-${template.id}`}
                  >
                    <Star className="h-4 w-4" fill={template.isFavorite ? "currentColor" : "none"} />
                  </button>
                </div>
                <CardContent className="p-4">
                  <h4 className="font-semibold mb-1">{template.title}</h4>
                  <p className="text-sm text-muted-foreground mb-2">{template.description}</p>
                  <div className="flex gap-2">
                    <Badge variant="secondary" className="text-xs">
                      {template.category}
                    </Badge>
                    {template.isFavorite && (
                      <Badge className="text-xs bg-yellow-500/20 text-yellow-700">
                        Favorito
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Expanded Color Palette */}
      <Card className="glass rounded-xl">
        <CardContent className="p-6">
          <h3 className="text-xl font-serif font-bold mb-4 flex items-center gap-2">
            🎨 Paleta del Día - Expandida
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {COLOR_PALETTE.map((color, index) => (
              <div key={index} className="space-y-2">
                <div 
                  className="color-swatch cursor-pointer aspect-square rounded-lg" 
                  style={{ backgroundColor: color.hex }}
                  onClick={() => copyColor(color.hex)}
                  title={`Copiar ${color.name}`}
                  data-testid={`expanded-color-${index}`}
                />
                <div className="text-center">
                  <p className="text-sm font-medium text-foreground">{color.name}</p>
                  <p className="text-xs font-mono text-muted-foreground">{color.hex}</p>
                  <p className="text-xs text-muted-foreground">{color.rgb}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Competition & References */}
      <Card className="glass rounded-xl">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-serif font-bold flex items-center gap-2">
              🔍 Competencia y Referencias
            </h3>
            <Button 
              onClick={addNewReference}
              className="hover-lift" 
              data-testid="button-add-reference"
            >
              <Plus className="w-4 h-4 mr-2" />
              Agregar Referencia
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {references.map((reference) => (
              <Card key={reference.id} className="hover-lift transition-smooth">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <img 
                      src={reference.imageUrl} 
                      alt={reference.title}
                      className="w-20 h-20 rounded-lg object-cover"
                      onError={(e) => {
                        e.currentTarget.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTUwIiBoZWlnaHQ9IjE1MCIgdmlld0JveD0iMCAwIDE1MCAxNTAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxNTAiIGhlaWdodD0iMTUwIiBmaWxsPSIjRjNGNEY2Ii8+CjxwYXRoIGQ9Ik02NyA3NUw3MyA4MUw3OSA3NUw3MyA2OUw2NyA3NVoiIGZpbGw9IiM5Q0EzQUYiLz4KPC9zdmc+';
                      }}
                    />
                    <div className="flex-1">
                      <h4 className="font-semibold mb-1">{reference.title}</h4>
                      <p className="text-sm text-muted-foreground mb-2">{reference.description}</p>
                      <div className="flex gap-2">
                        <Badge 
                          className={`text-xs ${
                            reference.status === 'high-competition' 
                              ? 'bg-yellow-500/20 text-yellow-700 dark:text-yellow-400' 
                              : 'bg-green-500/20 text-green-700 dark:text-green-400'
                          }`}
                        >
                          {reference.status === 'high-competition' ? 'Alta competencia' : 'Inspiración'}
                        </Badge>
                      </div>
                    </div>
                    <Button variant="outline" size="icon" data-testid={`button-view-reference-${reference.id}`}>
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {references.length === 0 && (
            <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
              <Plus className="h-12 w-12 text-muted-foreground mb-4 mx-auto" />
              <h4 className="font-semibold mb-2 text-muted-foreground">No hay referencias</h4>
              <p className="text-sm text-muted-foreground mb-4">Agrega referencias de la competencia e inspiraciones</p>
              <Button onClick={addNewReference} data-testid="button-add-first-reference">
                Agregar Primera Referencia
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
