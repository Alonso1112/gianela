import { useEffect, useState } from 'react';

const ROMANTIC_PHRASES = [
  "Eres la inspiración más hermosa 💖",
  "Tu creatividad ilumina este espacio ✨",
  "Cada día contigo es mágico 🌙",
  "Eres mi obra de arte favorita 🎨",
  "Tu talento brilla como las estrellas ⭐",
  "Juntos creamos magia 💫",
  "Eres el color que ilumina mi vida 🌈",
  "Tu sonrisa es mi inspiración diaria ☀️",
  "Contigo todo es posible 💕",
  "Eres mi musa perfecta 🌸",
  "Tu esencia es pura creatividad 🦋",
  "Eres la melodía de mi corazón 🎵",
  "Contigo el mundo es más hermoso 🌺",
  "Eres mi felicidad infinita 💝",
  "Tu amor es mi mayor motivación 💗"
];

export default function FloatingMessage() {
  const [currentMessage, setCurrentMessage] = useState('');
  const [isVisible, setIsVisible] = useState(false);
  const [phraseIndex, setPhraseIndex] = useState(0);

  useEffect(() => {
    const showMessage = () => {
      setCurrentMessage(ROMANTIC_PHRASES[phraseIndex]);
      setIsVisible(true);
      
      setTimeout(() => {
        setIsVisible(false);
      }, 5000);
      
      setPhraseIndex((prevIndex) => (prevIndex + 1) % ROMANTIC_PHRASES.length);
    };

    // Show first message after 5 seconds
    const firstTimeout = setTimeout(showMessage, 5000);
    
    // Then show every 5 minutes (300000ms)
    const interval = setInterval(showMessage, 300000);

    return () => {
      clearTimeout(firstTimeout);
      clearInterval(interval);
    };
  }, [phraseIndex]);

  if (!isVisible) return null;

  return (
    <div className="floating-message fade-in" data-testid="floating-message">
      💌 {currentMessage}
    </div>
  );
}
