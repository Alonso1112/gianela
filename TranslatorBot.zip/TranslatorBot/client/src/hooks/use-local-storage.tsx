import { useState, useEffect } from 'react';

export function useLocalStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(`Error loading ${key} from localStorage:`, error);
      return initialValue;
    }
  });

  const setValue = (value: T | ((val: T) => T)) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
      
      // Show auto-save indicator
      const indicator = document.createElement('div');
      indicator.className = 'save-indicator';
      indicator.textContent = 'Guardado ✓';
      document.body.appendChild(indicator);
      
      setTimeout(() => {
        indicator.remove();
      }, 2000);
    } catch (error) {
      console.error(`Error saving ${key} to localStorage:`, error);
    }
  };

  return [storedValue, setValue] as const;
}

export function useAutoSave<T>(key: string, value: T, delay: number = 2000) {
  useEffect(() => {
    const handler = setTimeout(() => {
      try {
        localStorage.setItem(key, JSON.stringify(value));
      } catch (error) {
        console.error(`Error auto-saving ${key}:`, error);
      }
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [key, value, delay]);
}
