import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || import.meta.env.VITE_GEMINI_API_KEY || ""
});

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export async function sendChatMessage(message: string, history: ChatMessage[] = []): Promise<string> {
  try {
    const contents = history.map(msg => ({
      role: msg.role === 'user' ? 'user' : 'model',
      parts: [{ text: msg.content }]
    }));
    
    contents.push({
      role: 'user',
      parts: [{ text: message }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents,
      config: {
        systemInstruction: "Eres un asistente creativo especializado en diseño, marketing y branding. Ayudas a Gianela con sus proyectos creativos de manera cálida, profesional y con toques románticos. Responde en español de manera clara y útil."
      }
    });

    return response.text || "Lo siento, no pude generar una respuesta.";
  } catch (error) {
    console.error("Error en chat con Gemini:", error);
    return "Error al conectar con el asistente. Verifica tu conexión.";
  }
}

export interface BrandingResponse {
  names: string[];
  slogans: string[];
  concepts: string;
}

export async function generateBranding(industry: string, values: string, target: string): Promise<BrandingResponse> {
  try {
    const prompt = `
      Genera ideas de branding para:
      - Industria: ${industry}
      - Valores de marca: ${values}
      - Público objetivo: ${target}
      
      Proporciona 5 nombres de marca creativos, 3 slogans/taglines atractivos, y 1 párrafo con conceptos de marca.
      Responde en formato JSON con las llaves: names (array), slogans (array), concepts (string).
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            names: { type: "array", items: { type: "string" } },
            slogans: { type: "array", items: { type: "string" } },
            concepts: { type: "string" }
          },
          required: ["names", "slogans", "concepts"]
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    return {
      names: result.names || [],
      slogans: result.slogans || [],
      concepts: result.concepts || ""
    };
  } catch (error) {
    console.error("Error generando branding:", error);
    return {
      names: ["Error al generar nombres"],
      slogans: ["Error al generar slogans"],
      concepts: "Error al generar conceptos"
    };
  }
}

export async function generateImage(prompt: string, style: string = "Fotográfico"): Promise<string | null> {
  try {
    const enhancedPrompt = `${prompt}. Estilo: ${style}. Alta calidad, composición profesional.`;
    
    // Note: Image generation requires special model
    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash-preview-image-generation",
      contents: [{ role: "user", parts: [{ text: enhancedPrompt }] }],
      config: {
        responseModalities: ["TEXT", "IMAGE"]
      }
    });

    const candidates = response.candidates;
    if (!candidates || candidates.length === 0) {
      return null;
    }

    const content = candidates[0].content;
    if (!content || !content.parts) {
      return null;
    }

    for (const part of content.parts) {
      if (part.inlineData && part.inlineData.data) {
        // Return base64 data URL
        return `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
      }
    }

    return null;
  } catch (error) {
    console.error("Error generando imagen:", error);
    return null;
  }
}
